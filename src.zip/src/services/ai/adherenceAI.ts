export { detectAdherenceConcern } from './index'
