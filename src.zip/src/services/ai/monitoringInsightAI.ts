export { generateMonitoringInsights } from './index'
