export { detectVitalTrend } from './index'
